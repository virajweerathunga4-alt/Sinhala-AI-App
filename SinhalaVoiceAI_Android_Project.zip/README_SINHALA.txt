Sinhala Voice AI - Android project

මේ app එක:
1. සිංහලෙන් කතා කරලා ප්‍රශ්නයක් අහන්න පුළුවන්.
2. AI එකෙන් text උත්තරයක් ගන්නවා.
3. උත්තරය සිංහල TTS voice එකකින් කියනවා.
4. Text එකෙන් ප්‍රශ්න අහන්නත් පුළුවන්.

වැදගත්:
- OpenAI API key එක app එකට ඔබම දාන්න.
- API usage සඳහා ඔබගේ OpenAI API account එකෙන් ගාස්තු අය විය හැක.
- API key එක වෙන කෙනෙකුට share කරන්න එපා.
- මේ demo app එකේ key එක local Android SharedPreferences එකේ තබනවා. Production app එකකට secure backend එකක් භාවිතා කිරීම වඩා ආරක්ෂිතයි.

Android Studio:
- මෙම ZIP එක extract කර Android Studio → Open කරන්න.
- Gradle sync ඉවර වෙනකම් ඉන්න.
- Phone එක USB debugging සමඟ connect කර Run කරන්න.
- නැත්නම් Build → Build APK(s) භාවිතා කරන්න.

Phone එකේ:
- Google Speech Services / Sinhala TTS support තිබිය යුතුයි.
- Internet අවශ්‍යයි.
