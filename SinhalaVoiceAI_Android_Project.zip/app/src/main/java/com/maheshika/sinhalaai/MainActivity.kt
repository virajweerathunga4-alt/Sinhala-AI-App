package com.maheshika.sinhalaai

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.content.Intent
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var question: EditText
    private lateinit var answer: TextView
    private lateinit var status: TextView
    private lateinit var apiKey: EditText
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        question = findViewById(R.id.question)
        answer = findViewById(R.id.answer)
        status = findViewById(R.id.status)
        apiKey = findViewById(R.id.apiKey)
        prefs = getSharedPreferences("settings", MODE_PRIVATE)
        apiKey.setText(prefs.getString("api_key", ""))

        tts = TextToSpeech(this, this)

        findViewById<Button>(R.id.saveKey).setOnClickListener {
            prefs.edit().putString("api_key", apiKey.text.toString().trim()).apply()
            status.text = "API key එක save කළා. දැන් ප්‍රශ්නයක් අහන්න."
        }

        findViewById<Button>(R.id.ask).setOnClickListener {
            askAI(question.text.toString().trim())
        }

        findViewById<Button>(R.id.mic).setOnClickListener {
            startListening()
        }

        findViewById<Button>(R.id.stopVoice).setOnClickListener {
            tts.stop()
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.RECORD_AUDIO), 10
            )
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "මේ phone එකේ Speech Recognition service එකක් නැහැ."
            return
        }

        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer!!.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "කතා කරන්න..." }
            override fun onBeginningOfSpeech() { status.text = "අහගෙන ඉන්නවා..." }
            override fun onEndOfSpeech() { status.text = "ඔයා කියපු දේ process කරනවා..." }
            override fun onError(error: Int) { status.text = "Voice input error: $error" }
            override fun onResults(results: Bundle?) {
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = list?.firstOrNull().orEmpty()
                question.setText(text)
                askAI(text)
            }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "si-LK")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "සිංහලෙන් කතා කරන්න")
        }
        recognizer!!.startListening(intent)
    }

    private fun askAI(userText: String) {
        if (userText.isBlank()) {
            status.text = "ප්‍රශ්නයක් කියන්න හෝ ලියන්න."
            return
        }

        val key = apiKey.text.toString().trim().ifBlank {
            prefs.getString("api_key", "").orEmpty()
        }
        if (key.isBlank()) {
            status.text = "මුලින් OpenAI API key එක දාන්න."
            return
        }

        status.text = "AI උත්තරය හදනවා..."
        findViewById<Button>(R.id.ask).isEnabled = false

        thread {
            try {
                val url = URL("https://api.openai.com/v1/responses")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("Authorization", "Bearer $key")
                conn.setRequestProperty("Content-Type", "application/json")
                conn.doOutput = true
                conn.connectTimeout = 20000
                conn.readTimeout = 60000

                val input = JSONObject()
                    .put("role", "user")
                    .put("content", "සිංහලෙන් ස්වභාවිකව, පැහැදිලිව උත්තර දෙන්න. ප්‍රශ්නය: $userText")

                val body = JSONObject()
                    .put("model", "gpt-5.6-luna")
                    .put("input", JSONArray().put(input))
                    .toString()

                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

                val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                val responseText = stream.bufferedReader().use { it.readText() }

                if (conn.responseCode !in 200..299) {
                    throw Exception("API ${conn.responseCode}: $responseText")
                }

                val root = JSONObject(responseText)
                val output = root.optJSONArray("output")
                val sb = StringBuilder()

                if (output != null) {
                    for (i in 0 until output.length()) {
                        val item = output.optJSONObject(i) ?: continue
                        val content = item.optJSONArray("content") ?: continue
                        for (j in 0 until content.length()) {
                            val part = content.optJSONObject(j) ?: continue
                            if (part.optString("type") == "output_text") {
                                sb.append(part.optString("text"))
                            }
                        }
                    }
                }

                val result = sb.toString().ifBlank { "AI එකෙන් text උත්තරයක් ලැබුණේ නැහැ." }

                runOnUiThread {
                    answer.text = result
                    status.text = "හරි. තවත් ප්‍රශ්නයක් අහන්න."
                    speakSinhala(result)
                    findViewById<Button>(R.id.ask).isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread {
                    answer.text = "Error: ${e.message}"
                    status.text = "AI request එක අසාර්ථකයි."
                    findViewById<Button>(R.id.ask).isEnabled = true
                }
            }
        }
    }

    private fun speakSinhala(text: String) {
        val result = tts.setLanguage(Locale("si", "LK"))
        if (result == TextToSpeech.LANG_MISSING_DATA ||
            result == TextToSpeech.LANG_NOT_SUPPORTED) {
            status.text = "සිංහල TTS phone එකේ support නැහැ. Google Speech Services install/update කරන්න."
            return
        }
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sinhala_answer")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts.setLanguage(Locale("si", "LK"))
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }
}
